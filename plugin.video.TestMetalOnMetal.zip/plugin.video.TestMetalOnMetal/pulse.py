# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.TestMetalOnMetal'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)


xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ACCEPT_LIVE_SHOWS = "PLGuhlLazJwGsqskC5RY0qt8Pk0xclK14f"
YOUTUBE_CHANNEL_ACCEPT_OFFICIAL_VIDEOS = "PLF84630BDCCB15277"
YOUTUBE_CHANNEL_ACCEPT_BEST_OF = "PLe7ia_jeVGd_vsqcTDyeeOHawvqoBFGbK"
YOUTUBE_CHANNEL_ACDC_OFFICIAL_GREATEST_HITS = "PLQlc99hV-nkGWDaG-gJxwOfqp8jxyHaaQ"
YOUTUBE_CHANNEL_ACDC_BACK_IN_BLACK = "PLx1MDbsLNfVQixI3AkXu862cZHi5XMev1"
YOUTUBE_CHANNEL_ACDC_RIVER_PLATE = "PLx1MDbsLNfVTiAIYbfgqg_8mCPAjvBxeV"
YOUTUBE_CHANNEL_AMORPHIS_OFFICIAL_VIDEOS = "PLBCkm4VYo_DgzDg5O2-8UxgzZ6iVC_iza" 
YOUTUBE_CHANNEL_ANTHRAX_ANNIVERSARY = "PLFdcG9gTDhXxde_Dm4iG4djHA7BAcl9qJ" 
YOUTUBE_CHANNEL_ANTHRAX_LIVE_SHOWS = "PLGuhlLazJwGvoKFw5_qfcvr_Omoxix1cY" 
YOUTUBE_CHANNEL_ANTHRAX_VIDEOS = "PLFdcG9gTDhXy3V5W9XojnCO340WJEouaV"
YOUTUBE_CHANNEL_ANTHRAX_VIDEOS2 = "PLamrICcWG5Qfj9ykKcMAVIrYXiwhv5X1H"
YOUTUBE_CHANNEL_HELLFEST = "PL66OD4JjS_2NqUJ7OFnLvUlrxYKddG-oe" 
YOUTUBE_CHANNEL_WACKEN_2020 = "PLGuhlLazJwGtgW7lbAJ-P_zitY3JJQScx"
YOUTUBE_CHANNEL_WACKEN_3_SONGS = "PLGuhlLazJwGtlB4ugCq9cNCLnAD2JSkix"
YOUTUBE_CHANNEL_WACKEN_ALL_LIVE_SHOWS = "PLPfPNs01OQC3pLnvPFudbDoBEReM3xcRw"
YOUTUBE_CHANNEL_WACKEN_BEST_FULL_SHOWS = "PLGuhlLazJwGuxXN0Wo9nRes7rYPtfRLqN"
YOUTUBE_CHANNEL_WACKEN_BLACK_METAL_BANDS = "PLPfPNs01OQC0_wDTyJ_UWJKZOvBdN4fXt"
YOUTUBE_CHANNEL_WACKEN_DEATH_METAL_BANDS = "PLPfPNs01OQC1vKSeAX1xa7vfe3l1BD3Ks"
YOUTUBE_CHANNEL_WACKEN_GRINDCORE_EXTREME_METAL_BANDS = "PLPfPNs01OQC2KEypK4oYX9_pNuVMamUVI"
YOUTUBE_CHANNEL_WACKEN_HEAVY_ROCK_BANDS = "PLPfPNs01OQC3ET6JyUgbW6R5Yp8BReNFd"
YOUTUBE_CHANNEL_WACKEN_MEDIAVAL_METAL_BANDS = "PLPfPNs01OQC2iNfBOXBwUpy1XWnRSJuYv"
YOUTUBE_CHANNEL_WACKEN_MELODIC_DEATH_METAL_BANDS = "PLPfPNs01OQC2-vQ9ORH8LHgkTa36odnBu"
YOUTUBE_CHANNEL_WACKEN_METAL_ICONS = "PLPfPNs01OQC2aXVVsXN4xDbM2Nx-tZVcl"
YOUTUBE_CHANNEL_WACKEN_PAGAN_VIKING_METAL_BANDS = "PLPfPNs01OQC09sP2au8177_PpZag8e0jt"
YOUTUBE_CHANNEL_WACKEN_ROCK_ICONS = "PLPfPNs01OQC3_H1e978hugznB6S7ItZ8Q"
YOUTUBE_CHANNEL_WACKEN_SYMPHONIC_METAL_BANDS = "PLPfPNs01OQC001OWeN4j4o-UmdK7SBiwP"
YOUTUBE_CHANNEL_WACKEN_THRASH_METAL_BANDS = "PLPfPNs01OQC1W-iGG0wy0Oo3W4ihaZZAi"
YOUTUBE_CHANNEL_SHAUN_TRACK_METAL = "PLgyUYejNPEs2N30vrCZHF6sgae6teIUjs"
YOUTUBE_CHANNEL_SHAUN_TRACK_ROCK = "PLgyUYejNPEs2pL_5qiAEe1V5hIw7rlUjy"
YOUTUBE_CHANNEL_30_YEARS_OF_NUCLEAR_BLAST = "PLB4brr7vf-P4Sw27U1AsJvIevX5D7TQeW"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Accept Live Shows",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACCEPT_LIVE_SHOWS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3drTXXLxUxGqP1Auzo9WyYNPaU2FH-XFNJJU5EEAJu88marsVoG2LAjb33Xw6JhJT5RelL_6dH-NvVeHZHdlZtmgrTRoC2msb_om7oLGLUL_L_0mNuZa9g1zIWzLz8_7ABNnnwKXDx-WVk-c9nS9nI",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Accept Official Videos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACCEPT_OFFICIAL_VIDEOS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3drTXXLxUxGqP1Auzo9WyYNPaU2FH-XFNJJU5EEAJu88marsVoG2LAjb33Xw6JhJT5RelL_6dH-NvVeHZHdlZtmgrTRoC2msb_om7oLGLUL_L_0mNuZa9g1zIWzLz8_7ABNnnwKXDx-WVk-c9nS9nI",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Accept Official Best of",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACCEPT_BEST_OF+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3drTXXLxUxGqP1Auzo9WyYNPaU2FH-XFNJJU5EEAJu88marsVoG2LAjb33Xw6JhJT5RelL_6dH-NvVeHZHdlZtmgrTRoC2msb_om7oLGLUL_L_0mNuZa9g1zIWzLz8_7ABNnnwKXDx-WVk-c9nS9nI",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="AC/DC Official Greatest Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACDC_OFFICIAL_GREATEST_HITS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3cy1aSe_x0U-YXj8YbZOQew7YqgozrpWgUW-sZumBikLlts1twWyYE1I8wFr6Ei3w6Bldvp-O6fD34tyaPLeLIlexXgxe_vpUPE6APSrjeeW51tE2Yb5JIAcTlY6SNMKfhPBh84sU3BcoFOQbXxNz0",
        folder=True )  
                         
    plugintools.add_item( 
        #action="", 
        title="AC/DC Back in Black Videos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACDC_BACK_IN_BLACK+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3cy1aSe_x0U-YXj8YbZOQew7YqgozrpWgUW-sZumBikLlts1twWyYE1I8wFr6Ei3w6Bldvp-O6fD34tyaPLeLIlexXgxe_vpUPE6APSrjeeW51tE2Yb5JIAcTlY6SNMKfhPBh84sU3BcoFOQbXxNz0",
        folder=True )   

    plugintools.add_item( 
        #action="", 
        title="AC/DC Live River Plate 2009",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ACDC_RIVER_PLATE+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3cy1aSe_x0U-YXj8YbZOQew7YqgozrpWgUW-sZumBikLlts1twWyYE1I8wFr6Ei3w6Bldvp-O6fD34tyaPLeLIlexXgxe_vpUPE6APSrjeeW51tE2Yb5JIAcTlY6SNMKfhPBh84sU3BcoFOQbXxNz0",
        folder=True )   
         
    plugintools.add_item( 
        #action="", 
        title="Amorphis Official Videos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_AMORPHIS_OFFICIAL_VIDEOS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3d80QttJoRGRZiuN9g3tYVc6xSTMt7IHg8YqVDl0oFKbQ7M7n5sJKm3VGWCcZsfYpbMAAYnSd3FhSJAVTLLUMll9DnDaZOWcY-nRlE-1cIoi_5oL8f6yznsIothgGmM6CIkSA1uOVJb8S5h5zod4cQ",
        folder=True )


         
    plugintools.add_item( 
        #action="", 
        title="Anthrax Live Shows",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ANTHRAX_LIVE_SHOWS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3fA8J9KMQCAwHEUR_EauTRaDALC3fs7gacvSlj3VElPEfx-pGZTmx-0rRiTZmP6e54WY7UDzXco6SHWe9tt_NI0WRCwmL1Rnt-l7pqgbF1Hw0TtGaJrfdCfJVM6CxSa_1FCPkpGIfW1H_Ho2tpV1v8",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Anthrax Official Music Videos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ANTHRAX_VIDEOS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3fA8J9KMQCAwHEUR_EauTRaDALC3fs7gacvSlj3VElPEfx-pGZTmx-0rRiTZmP6e54WY7UDzXco6SHWe9tt_NI0WRCwmL1Rnt-l7pqgbF1Hw0TtGaJrfdCfJVM6CxSa_1FCPkpGIfW1H_Ho2tpV1v8",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Anthrax - XXXV Anniversary",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ANTHRAX_ANNIVERSARY+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3fA8J9KMQCAwHEUR_EauTRaDALC3fs7gacvSlj3VElPEfx-pGZTmx-0rRiTZmP6e54WY7UDzXco6SHWe9tt_NI0WRCwmL1Rnt-l7pqgbF1Hw0TtGaJrfdCfJVM6CxSa_1FCPkpGIfW1H_Ho2tpV1v8",
        folder=True )        
    plugintools.add_item( 
        #action="", 
        title="Anthrax Music Videos 1984-2017",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ANTHRAX_VIDEOS2+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3fA8J9KMQCAwHEUR_EauTRaDALC3fs7gacvSlj3VElPEfx-pGZTmx-0rRiTZmP6e54WY7UDzXco6SHWe9tt_NI0WRCwmL1Rnt-l7pqgbF1Hw0TtGaJrfdCfJVM6CxSa_1FCPkpGIfW1H_Ho2tpV1v8",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Hellfest",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_HELLFEST+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3c4lz60GGELnzyZ_kPFs548d6X_vlMspbpLn5liLWoGwT8U_pQDVvYO2RoHqOsbV0hLKYXT4_oO9ehmrWaLXEYWbuQJxbJA0ZVggIefLLbC-VppPa98ypOgRm9w8u8cvii7sdQpIvCDw4EgYzRxCzk",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="Wacken World Wide 2020",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_2020+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Wacken All Live Shows",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_ALL_LIVE_SHOWS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Wacken Best Full Shows",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_BEST_FULL_SHOWS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Wacken - 3 Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_3_SONGS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Rock Icons",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_ROCK_ICONS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Wacken Metal Icons",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_ROCK_ICONS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Wacken Heavy Rock Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_HEAVY_ROCK_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Wacken Thrash Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_THRASH_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Symphonic Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_SYMPHONIC_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Death Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_DEATH_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Wacken Melodic Death Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_MELODIC_DEATH_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Black Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_BLACK_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Grindcore and Extreme Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_GRINDCORE_EXTREME_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Pagan and Viking Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_PAGAN_VIKING_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wacken Mediaval Metal Bands",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_WACKEN_MEDIAVAL_METAL_BANDS+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="Metal Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_SHAUN_TRACK_METAL+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3f-6GceBe3xgMWfWNkNL6HYkh6leNi394lieUmMD5iDO3OgssS2G8qvwL3EeQH2rAx5_-4kgFtYRWYh6vSTZ6NeBmPD2OZB3oreNaXLDSAKJNkWTreUwcY27Md9ax5A17fj8Jucf7qgeGwt3b265kY",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Rock and Pop Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_SHAUN_TRACK_ROCK+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3f-6GceBe3xgMWfWNkNL6HYkh6leNi394lieUmMD5iDO3OgssS2G8qvwL3EeQH2rAx5_-4kgFtYRWYh6vSTZ6NeBmPD2OZB3oreNaXLDSAKJNkWTreUwcY27Md9ax5A17fj8Jucf7qgeGwt3b265kY",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="30 years of Nuclear Blast",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_30_YEARS_OF_NUCLEAR_BLAST+"/",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ePHX936xIpa6VYaw6UXMJwxow-GZ6huLA3zXtt1gR0uXZ1nXUoNWeij0tOpjzBMoMdAOaY19WGsQ2HGuk7aCesiyPJ1YeB-I8vJD_wTRttJBPxa3Ugb3KGrBIoCHYuB0fAXw_LR9DOmgZd2N7AYkc",
        folder=True )
run()
